<template>
  <div class="upload-btn-box">
    <el-upload :action="define.comUrl + uploadUrl" :headers="{ Authorization: $store.getters.token}"
      :accept="accept" :data="data" :on-success="handleSuccess" :before-upload="beforeUpload"
      :show-file-list="false" class="upload-btn">
      <el-button ref="uploadBtn" :type="buttonType" :icon="showIcon?'el-icon-upload2':''"
        :loading="loading">
        {{buttonText}}
      </el-button>
    </el-upload>
    <el-dialog title="导入预览" :visible.sync="dialogVisible"
    class="JNPF-dialog JNPF-dialog_center JNPF-dialog-add" :close-on-click-modal="false"
    lock-scroll width="600px">
      <el-tabs type="border-card">
        <el-tab-pane label="流程">
          <el-table :data="tableData.templateEntity?[tableData.templateEntity]:[]" stripe style="width: 100%">
            <el-table-column prop="fullName" label="流程名称">
            </el-table-column>
            <el-table-column prop="enCode" label="流程编码" width="180">
            </el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane label="表单">
          <el-table :data="tableData.flowFormList" stripe style="width: 100%">
            <el-table-column prop="fullName" label="表单名称">
            </el-table-column>
            <el-table-column prop="enCode" label="表单编码" width="180">
            </el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane label="功能设计">
          <el-table :data="tableData.visualdevEntity" stripe style="width: 100%">
            <el-table-column prop="fullName" label="功能设计名称">
            </el-table-column>
            <el-table-column prop="enCode" label="功能设计编码" width="180">
            </el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane label="数据接口">
          <el-table :data="tableData.interfaceList" stripe style="width: 100%">
            <el-table-column prop="fullName" label="接口名称">
            </el-table-column>
            <el-table-column prop="enCode" label="接口编码" width="180">
            </el-table-column>
          </el-table>
        </el-tab-pane>
      </el-tabs>
      <div class="dialog-footer">
        <el-button @click="onCancel">取消</el-button>
        <el-button type="primary" @click="onSubmit" :loading="exportLoading">导入</el-button>
      </div>
    </el-dialog>
    <el-dialog title="确认信息" :visible.sync="comfirmDialogVisible"
    class="JNPF-dialog JNPF-dialog_center JNPF-dialog-add" :close-on-click-modal="false"
    lock-scroll width="600px">
      <div>
        {{comfirmData.reject.length?`以下数据接口无法导入：${comfirmData.reject.toString()}`: ''}}<br/>
        <div v-if="comfirmData.form.length">
          表单：<span class="danger-text">{{comfirmData.form.toString()}}</span> 已存在
        </div>
        <div v-if="comfirmData.interface.length">
          数据接口：<span class="danger-text">{{comfirmData.interface.toString()}}</span> 已存在
        </div>
      </div>
      <div class="dialog-footer">
        <el-button @click="onCancel">取消导入</el-button>
        <el-button type="primary" @click="isRecover(false)" :loading="exportLoading">不覆盖</el-button>
        <el-button type="danger" @click="isRecover(true)" :loading="exportLoading">覆盖</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { exportCheckFlowList, isCoverFlowList } from '@/api/workFlow/FlowEngine'
export default {
  name: 'JNPF-workflow-uploadBtn',
  data() {
    return {
      uploadUrl: '/api/workflow/Engine/flowTemplate/Actions/ImportDataView',
      loading: false,
      exportLoading: false,
      recoverLoading: false,
      dialogVisible: false,
      comfirmDialogVisible: false,
      comfirmData: {
        reject: [],
        form: [],
        interface: []
      },
      tableData: {
        templateEntity: [],
        flowFormList: [],
        visualdevEntity: [],
        interfaceList: []
      }
    }
  },
  props: {
    url: {
      type: String,
      default: ""
    },
    buttonText: {
      type: String,
      default: '导入'
    },
    buttonType: {
      type: String,
      default: 'text'
    },
    data: {
      type: Object,
      default: () => { }
    },
    showIcon: {
      type: Boolean,
      default: true
    },
    accept: {
      type: String,
      default: '*'
    },
  },
  methods: {
    beforeUpload() {
      this.loading = true
    },
    onCancel() {
      this.dialogVisible = false;
      this.comfirmDialogVisible = false;
    },
    onSubmit() {
      this.exportLoading = true;
      exportCheckFlowList(this.tableData).then((res) => {
        let { data } = res
        if(data){
          // 确认是否覆盖
          this.comfirmDialogVisible = true;
          this.comfirmData = data;
        }else{
          // 不覆盖
          this.isRecover(false);
        }
      }).finally(e=>{
        this.exportLoading = false;
      })
    },
    /**是否覆盖流程配置 
     * @params tag Boolean 是否覆盖
     */
    isRecover(tag) {
      this.exportLoading = true;
      isCoverFlowList({ ...this.tableData, recover: tag}).then((res) => {
        this.dialogVisible = false;
        this.comfirmDialogVisible = false;
        this.$message({ message: res.msg, type: 'success', duration: 1000 });
        this.$emit('on-success');
      }).finally(e=>{
        this.exportLoading = false;
      })
    },
    handleSuccess(res) {
      this.loading = false
      let { code, data, msg } = res;
      if (code == 200) {
        this.dialogVisible = true;
        this.tableData = data;
      } else {
        this.$message({
          message: msg,
          type: 'error',
          duration: 1000
        })
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.upload-btn-box {
  display: inline-block;
  .upload-btn {
    display: inline-block;
    margin: 0 10px;
  }
  .danger-text{
    color: #f00;
  }
  .dialog-footer {
    margin-top: 12px;
    float: right;
  }
}
</style>