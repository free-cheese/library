<template>
  <el-alert v-bind="$attrs" v-on="$listeners" />
</template>

<script>
export default {
  name: 'JnpfAlert',
};
</script>