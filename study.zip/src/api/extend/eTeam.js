import request from '@/utils/request'

// 获取eTeam列表
export function ETeamList(data) {
    return request({
        url: `/api/tapeOut/ETeam/list`,
        method: 'get',
        data
    })
}
// 获取eTeam详细信息
export function ETeamDetail(id) {
    return request({
        url: `/api/tapeOut/ETeam/${id}`,
        method: 'get',
    })
}
// 删除ETeam
export function ETeamDelete(id) {
    return request({
        url: `/api/tapeOut/ETeam/${id}`,
        method: 'DELETE'
    })
}
// 复制ETeam，查详细信息
export function ETeamCopy(id) {
    return request({
        url: `/api/tapeOut/ETeam/${id}/copy`,
        method: 'get'
    })
}
// 升版ETeam，查详细信息
export function ETeamUp(id) {
    return request({
        url: `/api/tapeOut/ETeam/${id}/up`,
        method: 'get'
    })
}
// 获取所有用户
export function userList(data) {
    return request({
        url: `/api/system/DataInterface/507439967354488325/Actions/Preview`,
        method: 'post',
        data
    })
}
// 获取Mask Information
export function GoodsList(data) {
    return request({
        url: `/api/tapeOut/ETeamApi/mask/search?maskCode=${data.maskCode}&maskName=${data.maskName}&maskPurpose=${data.maskPurpose}`,
        method: 'get',
    })
}
// 获取直属领导人
export function getManagerByUser(data) {
    return request({
        url: `/api/permission/Users/getManagerByUser?userId=${data}`,
        method: 'post',
    })
}
// 
export function getFlowFath(data) {
    return request({
        url: `/api/tapeOut/ETeamApi/detail?userId=${data.userId}&taskId=${data.taskId}`,
        method: 'get',
    })
}