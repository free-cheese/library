import request from '@/utils/request'

// 获取ProductBody列表
export function ProductBodyList(data) {
    return request({
        url: `/api/tapeOut/product/list`,
        method: 'post',
        data
    })
}
// 删除ProductBody
export function ProductBodyDelete(id) {
    return request({
        url: `/api/tapeOut/product/${id}`,
        method: 'DELETE'
    })
}
// 获取所有用户
export function userList(data) {
    return request({
        url: `/api/system/DataInterface/507439967354488325/Actions/Preview`,
        method: 'post',
        data
    })
}
// product id列表查询获取非草稿状态的techId
export function techIdList() {
    return request({
        url: `/api/system/DataInterface/553539911702084549/Actions/Preview`,
        method: 'post',
    })
}
// product body获取techId，type=1查body里面新增的TechId，type=2查body里面升版的TechId，type=3查除draft状态之外的所有状态的TechId
export function productTechIdList(data) {
    return request({
        url: `/api/tapeOut/ETeamApi/techList?type=${data.type}&id=${data.id}`,
        method: 'get',
    })
}
// 复制ProductBody，查详细信息
export function ProductBodyCopy(id) {
    return request({
        url: `/api/tapeOut/product/${id}/copy`,
        method: 'get'
    })
}
// 升版ProductBody，查详细信息
export function ProductBodyUp(id) {
    return request({
        url: `/api/tapeOut/product/${id}/up`,
        method: 'get'
    })
}
// 获取ProductId列表
export function ProductIdList(data) {
    return request({
        url: `/api/tapeOut/productId/list`,
        method: 'post',
        data
    })
}
// 删除ProductId
export function ProductIdDelete(id) {
    return request({
        url: `/api/tapeOut/productId/del/${id}`,
        method: 'DELETE'
    })
}
// 获取Mask Information
export function MaskList(data) {
    return request({
        url: `/api/tapeOut/productId/getMaskInfoByProductBodyId?productBodyId=${data}`,
        method: 'get',
    })
}
// 获取直属领导人
export function getManagerByUser(data) {
    return request({
        url: `/api/permission/Users/getManagerByUser?userId=${data}`,
        method: 'post',
    })
}
// 流程跳转详情
export function getFlowFath(data) {
    return request({
        url: `/api/tapeOut/ETeamApi/detail?userId=${data.userId}&techId=${data.techId}`,
        method: 'get',
    })
}
// 根据Tech ID获取Platform 、Sub Platform的值
export function getPlatform(id) {
    return request({
        url: `/api/tapeOut/ETeam/${id}`,
        method: 'get',
    })
}