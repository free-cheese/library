import request from '@/utils/request'

let baseInfo = 'api/tapeOut/testKeyRecord/'

/*.....................LayerInfo列表.....................*/
// 获取列表数据
export function getListData(data) {
    return request({
        url: baseInfo + `listTable`,
        method: 'post',
        data
    })
}
// 启用禁用
export function isEnable(data) {
    return request({
        url: `/api/tapeOut/LayerInfoApi/updateStatus?name=${data.name}&type=${data.type}&status=${data.status}`,
        method: 'get',
    })
}
// 导出layerInfo数据
export function exportData() {
    return request({
        url: `/api/tapeOut/LayerInfoApi/exportMerge`,
        method: 'get',
    })
}
// 导出layerGroup数据
export function exportGroupData() {
    return request({
        url: `/api/tapeOut/LayerInfoApi/exportGroup`,
        method: 'get',
    })
}
// 导出layerType数据
export function exportTypeData() {
    return request({
        url: `/api/tapeOut/LayerInfoApi/exportType`,
        method: 'get',
    })
}
// 日志
export function listJournalData(data) {
    return request({
        url: `/api/tapeOut/LayerInfoApi/getLogs/${data.id}/${data.type}/${data.pageSize}/${data.currentPage}`,
        method: 'get',
    })
}


/*.....................LayerInfo新增.....................*/
// 获取所有用户
export function userList(data) {
    return request({
        url: `/api/system/DataInterface/507439967354488325/Actions/Preview`,
        method: 'post',
        data
    })
}
// 获取直属领导人
export function getManagerByUser(data) {
    return request({
        url: `/api/permission/Users/getManagerByUser?userId=${data}`,
        method: 'post',
    })
}
// 下载导入模板
export function exportTemplate(data) {
    return request({
        url: `/api/tapeOut/LayerInfo/importTemplate`,
        method: 'post',
        data
    })
}
// 查询当前用户是否存在DS群组权限
export function authority(data) {
    return request({
        url: `/api/tapeOut/LayerInfoApi/isGroupMember/${data}`,
        method: 'get'
    })
}

/*.....................layerMapping列表.....................*/
// 获取layerMapping列表数据
export function mappingList(data) {
    return request({
        url: `/api/tapeOut/LayerMapping/list`,
        method: 'get',
        data
    })
}
// 删除
export function mappingDelete(id) {
    return request({
        url: `/api/tapeOut/LayerMapping/${id}`,
        method: 'DELETE',
    })
}
// 复制
export function flowCopy(data) {
    return request({
        url: baseInfo + `copyTestKeyRecord`,
        method: 'get',
        data
    })
}
// 升版
export function mappingUp(id) {
    return request({
        url: `/api/tapeOut/LayerMapping/${id}/up`,
        method: 'get',
    })
}
// 导出
export function exportMappingData(data) {
    return request({
        url: `/api/tapeOut/LayerMappingApi/exportLayerMapping/${data}`,
        method: 'get',
    })
}
// 查看
export function checkData(id) {
    return request({
        url: `/api/tapeOut/LayerMappingApi/checkInfo/${id}`,
        method: 'get',
    })
}

/*.....................layerMapping新增.....................*/

// 下载导入模板
export function exportMappingTemplate() {
    return request({
        url: `/api/tapeOut/LayerMapping/importTemplate`,
        method: 'post',
    })
}
// 获取layerInfo弹出框列表数据
export function layerInfoData(data) {
    return request({
        url: `/api/tapeOut/LayerMappingApi/layerInfoList`,
        method: 'get',
        data
    })
}
// 选择tech Table，判断是否已有相同Tech Table在审核中/有效状态
export function changeTechTable(data) {
    return request({
        url: `/api/tapeOut/LayerMappingApi/ifTechTableAvailable/${data}`,
        method: 'get',
    })
}