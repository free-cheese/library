import request from '@/utils/request'

// 获取lota列表
export function lotaList(data) {
    return request({
        url: `/api/tapeOut/loTaRecord/listTable`,
        method: 'post',
        data
    })
}
// 获取lota详细信息
export function lotaDetail(id) {
    return request({
        url: `/api/tapeOut/lota/${id}`,
        method: 'get',
    })
}
// 删除lota
export function lotaDelete(id) {
    return request({
        url: `/api/tapeOut/loTaRecord/deleteLoTaRecord?id=${id}`,
        method: 'DELETE',
    })
}
// 复制lota，查详细信息
export function lotaCopy(id) {
    return request({
        url: `/api/tapeOut/loTaRecord/copyLoTaRecord?id=${id}`,
        method: 'get'
    })
}
// 升版lota，查详细信息
export function lotaUp(id) {
    return request({
        url: `/api/tapeOut/loTaRecord/${id}/up`,
        method: 'get'
    })
}
// 获取所有用户
export function userList(data) {
    return request({
        url: `/api/system/DataInterface/507439967354488325/Actions/Preview`,
        method: 'post',
        data
    })
}
// 获取Mask Information
export function GoodsList(data) {
    return request({
        url: `/api/tapeOut/ETeamApi/mask/search?maskCode=${data.maskCode}&maskName=${data.maskName}&maskPurpose=${data.maskPurpose}`,
        method: 'get',
    })
}
// 下载导入模板Mask Information
export function downloadTemplate() {
    return request({
        url: `/api/tapeOut/loTaRecord/importTemplate`,
        method: 'post',
    })
}
// 导入模板数据Mask Information
export function importTemplate(data) {
    return request({
        url: `/api/tapeOut/loTaRecord/verifyImportedData`,
        method: 'post',
        data
    })
}
// 导出公式
export function exportFormulaTemplate(data) {
    return request({
        url: `/api/tapeOut/loTaRecord/exportMaskData`,
        method: 'post',
        data
    })
}
// 编辑公式最后保存校验
export function checkLogic(data) {
    return request({
        url: `/api/tapeOut/LotaApi/check`,
        method: 'post',
        data
    })
}
// 解析Logic Operation
export function analysisLogic(data) {
    return request({
        url: `/api/tapeOut/LotaApi/analysis`,
        method: 'post',
        data
    })
}
// 分解Logic Operation
export function disassembleLogic(data) {
    return request({
        url: `/api/tapeOut/LotaApi/disassemble`,
        method: 'post',
        data
    })
}
//合成Logic Operation
export function synthetizeLogic(data,maskName) {
    return request({
        url: `/api/tapeOut/LotaApi/synthesize?maskName=${maskName}`,
        method: 'post',
        data
    })
}
// 获取直属领导人
export function getManagerByUser(data) {
    return request({
        url: `/api/permission/Users/getManagerByUser?userId=${data}`,
        method: 'post',
    })
}
// 
export function getFlowFath(data) {
    return request({
        url: `/api/tapeOut/ETeamApi/detail?userId=${data.userId}&taskId=${data.taskId}`,
        method: 'get',
    })
}