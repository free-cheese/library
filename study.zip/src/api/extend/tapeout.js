import request from '@/utils/request'


// 获取tapeout列表
export function tapeOutList(data) {
    return request({
        url: `/api/tapeOut/toRecord/list`,
        method: 'post',
        data
    })
}
// 删除tapeout
export function tapeoutDelete(id) {
    return request({
        url: `/api/tapeOut/toRecord/deleteToRecord?id=${id}`,
        method: 'DELETE'
    })
}
// 获取ProductBody信息
export function getAllProductBodyList(data) {
    return request({
        url: `/api/tapeOut/toRecordApi/getAllProductBodyList`,
        method: 'post',
        data
    })
}
// 获取所有用户
export function userList(data) {
    return request({
        url: `/api/system/DataInterface/507439967354488325/Actions/Preview`,
        method: 'post',
        data
    })
}

// 获取直属领导人
export function getManagerByUser(data) {
    return request({
        url: `/api/permission/Users/getManagerByUser?userId=${data}`,
        method: 'post',
    })
}
// 根据ProductBody获取mask
export function maskList(data,techId) {
    return request({
        url: `/api/tapeOut/toRecord/getMaskInfosByProductBody?productBody=${data}&techId=${techId}`,
        method: 'get',
    })
}
// 复制，查详细信息
export function toRecordCopy(id) {
    return request({
        url: `/api/tapeOut/toRecord/copyToRecord?id=${id}`,
        method: 'get'
    })
}
// 检查是否tapeOut
export function checkOutTapeOut(data) {
    return request({
        url: `/api/tapeOut/toRecord/checkOutTapeOut?productBody=${data.productBody}&maskCode=${data.maskCode}&customerType=${data.customerType}`,
        method: 'get',
    })
}
// 检查是否tapeOutList
export function checkOutTapeOutList(data) {
    return request({
        url: `/api/tapeOut/toRecord/checkOutTapeOutList`,
        method: 'post',
        data
    })
}
// 获取techId
export function techIdList() {
    return request({
        url: `/api/system/DataInterface/511901264494210373/Actions/Preview`,
        method: 'post',
    })
}
// 下载数据
export function exportFormulaTemplate(data) {
    return request({
        url: `/api/tapeOut/toRecordApi/download`,
        method: 'post',
        data
    })
}